# carhouse-website
A beautiful website for your luxury car

#First section of te sie
<img width="951" alt="pic1" src="https://github.com/JohnnyLouisTech/carhouse-website/assets/29494723/5079b566-b50d-4ba5-8956-dd1d448ce5cb">

#Second section of the site
<img width="951" alt="pic 2" src="https://github.com/JohnnyLouisTech/carhouse-website/assets/29494723/e403ba05-73ad-4ba6-89d9-f32b929a9eb4">

#Third section of the site
<img width="951" alt="pic3" src="https://github.com/JohnnyLouisTech/carhouse-website/assets/29494723/bd89c0d8-c852-4494-a74e-79aaa8739e95">

#Fourth section of the site
<img width="955" alt="pic4" src="https://github.com/JohnnyLouisTech/carhouse-website/assets/29494723/1452e32b-a368-40c7-96ea-29d70bc29d52">
